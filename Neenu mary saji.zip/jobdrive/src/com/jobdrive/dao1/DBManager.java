package com.jobdrive.dao1;

import java.sql.Date;
import java.util.List;

import com.jobdrive.model.Application;



public interface DBManager {
	public int registration( Date r_date, String description, String priority,Date v_sdate,Date v_edate,String assign );
	public List<Application> applicationList();
}
