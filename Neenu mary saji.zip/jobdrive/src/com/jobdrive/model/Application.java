package com.jobdrive.model;

import java.sql.Date;

public class Application {
	private int a_id;
	private Date r_date;
	private String description;
	private String priority;
	private Date v_sdate;
	private Date v_edate;
	private String assign;
	public Application(int a_id, Date r_date, String description, String priority, Date v_sdate, Date v_edate,
			String assign) {
		super();
		this.a_id = a_id;
		this.r_date = r_date;
		this.description = description;
		this.priority = priority;
		this.v_sdate = v_sdate;
		this.v_edate = v_edate;
		this.assign = assign;
	}
	public int getA_id() {
		return a_id;
	}
	public void setA_id(int a_id) {
		this.a_id = a_id;
	}
	public Date getR_date() {
		return r_date;
	}
	public void setR_date(Date r_date) {
		this.r_date = r_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Date getV_sdate() {
		return v_sdate;
	}
	public void setV_sdate(Date v_sdate) {
		this.v_sdate = v_sdate;
	}
	public Date getV_edate() {
		return v_edate;
	}
	public void setV_edate(Date v_edate) {
		this.v_edate = v_edate;
	}
	public String getAssign() {
		return assign;
	}
	public void setAssign(String assign) {
		this.assign = assign;
	}
	@Override
	public String toString() {
		return "Application [a_id=" + a_id + ", r_date=" + r_date + ", description=" + description + ", priority="
				+ priority + ", v_sdate=" + v_sdate + ", v_edate=" + v_edate + ", assign=" + assign + "]";
	}
	
}