package com.jobdrive.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrive.dao.impl.DBManagerImpl;
import com.jobdrive.dao1.DBManager;
import com.jobdrive.model.Application;




@WebServlet("/ApplicationServlet")
public class ApplicationServlet extends HttpServlet {
	List<Application>appli=new ArrayList<>();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DBManager db = new DBManagerImpl();
		appli = db.applicationList();
		request.setAttribute("appli", appli);
   	 
   	 RequestDispatcher rd = request.getRequestDispatcher("application.jsp");
        rd.forward(request,
                   response);
		
	}

	
}
