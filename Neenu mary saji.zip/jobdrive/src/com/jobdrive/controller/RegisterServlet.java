package com.jobdrive.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrive.dao.impl.DBManagerImpl;
import com.jobdrive.dao1.DBManager;




@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Date r_date = Date.valueOf(request.getParameter("r_date"));

		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		Date v_sdate = Date.valueOf(request.getParameter("v_sdate"));
		Date v_edate = Date.valueOf(request.getParameter("v_edate"));

		String assign = request.getParameter("assign");
		DBManager db = new DBManagerImpl();
		int count ;
		
		count=	db.registration( r_date, description, priority,v_sdate,v_edate,assign );
		System.out.println(count+"rows/s affected");
		RequestDispatcher rd = request.getRequestDispatcher("/result.jsp");
	        rd.forward(request,
	                   response);
	}

}
