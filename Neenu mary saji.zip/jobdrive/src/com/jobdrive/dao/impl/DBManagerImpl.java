package com.jobdrive.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jobdrive.dao1.DBManager;
import com.jobdrive.model.Application;

public class DBManagerImpl implements DBManager {
	Connection connection = null;
	PreparedStatement selectstmt = null;
	ResultSet rs = null;
	Statement stmt = null;
	String query = null;
	PreparedStatement pstmt = null;
	final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobdrive", "root", "admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int registration( Date r_date, String description, String priority, Date v_sdate, Date v_edate,String assign) {
		connection = getConnection();

		query ="insert into application(r_date,description,priority,v_sdate,v_edate,assign)values(?,?,?,?,?,?)";
		try {
			pstmt=connection.prepareStatement(query);
			pstmt.setDate(1, r_date);
			pstmt.setString(2, description);
			pstmt.setString(3, priority);
			pstmt.setDate(4, v_sdate);
			pstmt.setDate(5, v_edate);
			pstmt.setString(6, assign);
			
			
			
		
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count = 0;
		try {
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public List<Application> applicationList() {
		connection = getConnection();

		query = "SELECT * FROM APPLICATION";
		List<Application> list = new ArrayList<>();
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				System.out.println("inside while");
				int a_id = rs.getInt("a_id");
				Date r_date = rs.getDate("r_date");
				String description = rs.getString("description");
				String priority = rs.getString("priority");
				Date v_sdate = rs.getDate("v_sdate");
				Date v_edate = rs.getDate("v_edate");
				String assign = rs.getString("assign");

				list.add(new Application(a_id, r_date, description, priority,v_sdate,v_edate,assign));
				System.out.println(list);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
	}

	


