package com.jobapplication.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jobapplication.dao.DBManager;
import com.jobapplication.model.Registration;


public class DbManagerImpl implements DBManager{
	Connection connection = null;
	PreparedStatement selectstmt = null;
	ResultSet rs = null;
	Statement stmt = null;
	String query = null;
	PreparedStatement pstmt = null;
	final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/newapplication", "root", "Sanila@2529");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public int registration1( Date registration_date,String description, String priority, Date valid_start_date, Date valid_end_date,String assigned_recruiter) {
		connection = getConnection();

		query ="insert into registration(registration_date,description,priority,valid_start_date,valid_end_date,assigned_recruiters)values(?,?,?,?,?,?)";
		try {
			pstmt=connection.prepareStatement(query);
			pstmt.setDate(1, registration_date);
			pstmt.setString(2, description);
			pstmt.setString(3, priority);
			pstmt.setDate(4, valid_start_date);
			pstmt.setDate(5, valid_end_date);
			pstmt.setString(6, assigned_recruiter);
			
			
			
		
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count = 0;
		try {
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public List<Registration> applicationList() {
		connection = getConnection();

		query = "SELECT * FROM REGISTRATION";
		List<Registration> list = new ArrayList<>();
		try {
			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				System.out.println("inside while");
				int applicant_id = rs.getInt("applicant_id");
				Date registration_date = rs.getDate("registration_date");
				String description = rs.getString("description");
				String priority = rs.getString("priority");
				Date valid_start_date = rs.getDate("valid_start_date");
				Date valid_end_date = rs.getDate("valid_end_date");
				String assigned_recruiter = rs.getString("assigned_recruiter");

				list.add(new Registration(applicant_id,registration_date,description,priority,valid_start_date,valid_end_date,assigned_recruiter));
				System.out.println(list);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}


	

	

	}
