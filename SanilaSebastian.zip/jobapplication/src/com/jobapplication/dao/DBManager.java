package com.jobapplication.dao;

import java.sql.Date;
import java.util.List;

import com.jobapplication.model.Registration;



public interface DBManager {
	public int registration1( Date registration_date, String description, String priority,Date valid_start_date,Date valid_end_date,String assigned_recruiter );
	public List<Registration> applicationList();
}
