package com.jobapplication.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobapplication.dao.DBManager;
import com.jobapplication.dao.impl.DbManagerImpl;


/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Date registration_date = Date.valueOf(request.getParameter("registration_date"));

		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		Date valid_start_date = Date.valueOf(request.getParameter("valid_start_date"));
		Date valid_end_date = Date.valueOf(request.getParameter("valid_end_date"));

		String assigned_recruiter = request.getParameter("assigned_recruiter");
		DBManager db = new DbManagerImpl();
		int count ;
		
		count=	db.registration1(registration_date, description, priority,valid_start_date,valid_end_date,assigned_recruiter );
		System.out.println(count+"rows/s affected");
		RequestDispatcher rd = request.getRequestDispatcher("/result.jsp");
	        rd.forward(request,
	                   response);
	}

}
