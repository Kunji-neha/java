package com.jobapplication.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobapplication.dao.DBManager;
import com.jobapplication.dao.impl.DbManagerImpl;
import com.jobapplication.model.Registration;

/**
 * Servlet implementation class ApplicationServlet
 */
@WebServlet("/ApplicationServlet")
public class ApplicationServlet extends HttpServlet {
	List<Registration>appli=new ArrayList<>();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DBManager db = new DbManagerImpl();
		appli = db.applicationList();
		request.setAttribute("appli", appli);
   	 
   	 RequestDispatcher rd = request.getRequestDispatcher("registration.jsp");
        rd.forward(request,
                   response);
		
	}

	
}
