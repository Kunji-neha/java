package com.jobapplication.model;

import java.sql.Date;

public class Registration {
	private int applicant_id;
	private Date registration_date;
	private String description;
	private String priority;
	private Date valid_start_date;
	private Date valid_end_date;
	private String assigned_recruiter;
	public Registration(int applicant_id, Date registration_date, String description, String priority,
			Date valid_start_date, Date valid_end_date, String assigned_recruiter) {
		super();
		this.applicant_id = applicant_id;
		this.registration_date = registration_date;
		this.description = description;
		this.priority = priority;
		this.valid_start_date = valid_start_date;
		this.valid_end_date = valid_end_date;
		this.assigned_recruiter = assigned_recruiter;
	}
	public int getApplicant_id() {
		return applicant_id;
	}
	public void setApplicant_id(int applicant_id) {
		this.applicant_id = applicant_id;
	}
	public Date getRegistration_date() {
		return registration_date;
	}
	public void setRegistration_date(Date registration_date) {
		this.registration_date = registration_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Date getValid_start_date() {
		return valid_start_date;
	}
	public void setValid_start_date(Date valid_start_date) {
		this.valid_start_date = valid_start_date;
	}
	public Date getValid_end_date() {
		return valid_end_date;
	}
	public void setValid_end_date(Date valid_end_date) {
		this.valid_end_date = valid_end_date;
	}
	public String getAssigned_recruiter() {
		return assigned_recruiter;
	}
	public void setAssigned_recruiter(String assigned_recruiter) {
		this.assigned_recruiter = assigned_recruiter;
	}
	@Override
	public String toString() {
		return "Application [applicant_id=" + applicant_id + ", registration_date=" + registration_date + ", description=" + description + ", priority="
				+ priority + ", valid_start_date=" + valid_start_date + ", valid_end_date=" + valid_end_date + ", assign=" + assigned_recruiter + "]";
	}

	}
