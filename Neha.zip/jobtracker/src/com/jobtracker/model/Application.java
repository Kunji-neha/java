package com.jobtracker.model;

import java.sql.Date;

public class Application {
	private int application_id;
	private Date date;
	private String description;
	private String priority;
	private Date start_date;
	private Date end_date;
	private String recruter;

	public Application(Date date, String description, String priority, Date start_date, Date end_date,
			String recruter) {
		this.date = date;
		this.description = description;
		this.priority = priority;
		this.start_date = start_date;
		this.end_date = end_date;
		this.recruter = recruter;
	}

	public int getApplication_id() {
		return application_id;
	}

	public void setApplication_id(int application_id) {
		this.application_id = application_id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getRecruter() {
		return recruter;
	}

	public void setRecruter(String recruter) {
		this.recruter = recruter;
	}

}
