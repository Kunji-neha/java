package com.jobtracker.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobtracker.dao.DbManager;
import com.jobtracker.dao.impl.DbImpl;
import com.jobtracker.model.Application;

@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/add.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			Date date = Date.valueOf(request.getParameter("date"));
			String description = request.getParameter("description");
			String priority = request.getParameter("priority");
			Date start_date = Date.valueOf(request.getParameter("start_date"));
			Date end_date = Date.valueOf(request.getParameter("end_date"));
			String recruter = request.getParameter("recruter");
			/*
			 * System.out.println("in servlet"); System.out.println(date);
			 * System.out.println(description); System.out.println(priority);
			 * System.out.println(start_date); System.out.println(end_date);
			 * System.out.println(recruter);
			 */
			DbManager db = new DbImpl();
			Application application = new Application(date, description, priority, start_date, end_date, recruter);
			db.insert(application);

		} catch (Exception e) {
			e.printStackTrace();
		}
		RequestDispatcher rd = request.getRequestDispatcher("/msg.jsp");
		rd.forward(request, response);
	}

}
