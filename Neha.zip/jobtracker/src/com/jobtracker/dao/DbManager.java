package com.jobtracker.dao;

import java.sql.Connection;
import java.util.List;

import com.jobtracker.model.Application;

public interface DbManager {

	public void insert(Application application);

	public Connection getConnection();

	public List<Application> appList();
}
