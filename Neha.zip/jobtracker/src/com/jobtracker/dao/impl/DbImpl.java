package com.jobtracker.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jobtracker.dao.DbManager;
import com.jobtracker.model.Application;

public class DbImpl implements DbManager {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	@Override
	public Connection getConnection() {
		String url = "jdbc:mysql://localhost:3306/jobtracker";
		String user = "root";
		String pass = "root123";

		try {

			Connection connection = DriverManager.getConnection(url, user, pass);
			return connection;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public void insert(Application application) {
		con = getConnection();
		try {
			String sql2 = "insert into application(date,description,priority,start_date,end_date,recruter)values(?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql2);
			pst.setDate(1, application.getDate());
			pst.setString(2, application.getDescription());
			pst.setString(3, application.getPriority());
			pst.setDate(4, application.getStart_date());
			pst.setDate(5, application.getEnd_date());
			pst.setString(6, application.getRecruter());
			pst.executeUpdate();
			System.out.println("in method");
			System.out.println(application.getDate());
			System.out.println(application.getEnd_date());
			System.out.println();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Application> appList() {
		List<Application> app = new ArrayList();
		try {
			con = getConnection();
			String sql3 = "select date,description,priority,start_date,end_date,recruter from application";
			Statement pst2 = con.createStatement();
			rs = pst2.executeQuery(sql3);
			while (rs.next()) {
				Date date = rs.getDate("date");
				String description = rs.getString("description");
				String priority = rs.getString("priority");
				Date start_date = rs.getDate("start_date");
				Date end_date = rs.getDate("end_date");
				String recruter = rs.getString("recruter");
				app.add(new Application(date, description, priority, start_date, end_date, recruter));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return app;
	}
}
