package com.jobdrivesystem.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrivesystem.dao.DBManager;
import com.jobdrivesystem.dao.impl.DBManagerImpl;




@WebServlet("/NewApplicationServlet")
public class NewApplicationServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int app_id = Integer.parseInt(request.getParameter("app_id"));
		String reg_date = request.getParameter("reg_date");
		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		String start_date = request.getParameter("start_date");
		String end_date = request.getParameter("end_date");
		String assignedto = request.getParameter("assignedto");
		System.out.println("entered");
		DBManager db =  new DBManagerImpl();
		int list;
		list = db.addNewApplicant(app_id, reg_date, description, priority, start_date, end_date, assignedto);
		RequestDispatcher rd = request.getRequestDispatcher("/result.jsp");
		rd.forward(request, response);
		
	}

}
