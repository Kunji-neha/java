package com.jobdrivesystem.dao;

import java.util.List;

import com.jobdrivesystem.model.Applicant;

public interface DBManager {

	public int addNewApplicant(int app_id, String reg_date, String description,String priority,String start_date,String end_date,String assignedto);
	public List<Applicant> listOf();
}
