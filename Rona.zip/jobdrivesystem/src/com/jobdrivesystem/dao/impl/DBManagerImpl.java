package com.jobdrivesystem.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jobdrivesystem.dao.DBManager;
import com.jobdrivesystem.model.Applicant;


public class DBManagerImpl implements DBManager {

	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	String DB_URL = "jdbc:mysql://localhost:3306/jobdrive";
	String user = "root";
	String pass = "rona123@";
	
	@Override
	public int addNewApplicant(int app_id, String reg_date, String description, String priority, String start_date,
			String end_date, String assignedto) {
		
		int count = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, user, pass);
			String query = "INSERT INTO APPLICANT(APP_ID, REG_DATE, DESCRIPTION, PRIORITY, START_DATE, END_DATE, ASSIGNEDTO) VALUES(?, ?, ?, ?, ?, ?, ?)";
			ps = conn.prepareStatement(query);
			ps.setInt(1, app_id);
			ps.setString(2, reg_date);
			ps.setString(3, description);
			ps.setString(4, priority);
			ps.setString(5, start_date);
			ps.setString(6, end_date);
			ps.setString(7, assignedto);
			
			count = ps.executeUpdate();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count;
	}

	@Override
	public List<Applicant> listOf() {
		
		List<Applicant> lists = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, user, pass);
			String query = "SELECT * FROM APPLICANT";
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			System.out.println("entered impl");
			while(rs.next())
			{
				lists.add(new Applicant(rs.getInt("app_id"), rs.getString("reg_date"), rs.getString("description"), rs.getString("priority"), rs.getString("start_date"), rs.getString("end_date"), rs.getString("assignedto")));
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return lists;
	}
	
	
	
	}

