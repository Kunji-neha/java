package com.jobdrivesystem.model;

public class Applicant {

	int app_id;
	String reg_date;
	String description;
	String priority;
	String start_date;
	String end_date;
	String assignedto;
	public Applicant(int app_id, String reg_date, String description, String priority, String start_date,
			String end_date, String assignedto) {
		super();
		this.app_id = app_id;
		this.reg_date = reg_date;
		this.description = description;
		this.priority = priority;
		this.start_date = start_date;
		this.end_date = end_date;
		this.assignedto = assignedto;
	}
	public int getApp_id() {
		return app_id;
	}
	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}
	public String getReg_date() {
		return reg_date;
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	
	
}
