package com.job.model;

import java.sql.Date;

public class Register {
	private int id;
	private String date;
	private String description;
	private String priority;
	private String start_date;
	private String end_date;
	private String recruiter;
	public Register(int id, String date, String description, String priority, String start_date, String end_date,
			String recruiter) {
		super();
		this.id = id;
		this.date = date;
		this.description = description;
		this.priority = priority;
		this.start_date = start_date;
		this.end_date = end_date;
		this.recruiter = recruiter;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getRecruiter() {
		return recruiter;
	}
	public void setRecruiter(String recruiter) {
		this.recruiter = recruiter;
	}
		
}