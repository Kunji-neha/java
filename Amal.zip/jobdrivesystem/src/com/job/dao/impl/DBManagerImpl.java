package com.job.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.job.dao.DBManager;
import com.job.model.Register;

public class DBManagerImpl implements DBManager {
	Connection connection = null;
	PreparedStatement selectstmt = null;
	ResultSet rs = null;
	Statement stmt = null;
	String query = null;
	PreparedStatement pstmt = null;
	final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobsystem", "root", "Ust@1234");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public int registration(int id, String date, String description, String priority, String start_date,String end_date,String recruiter) {
		connection = getConnection();

		query ="insert into newreg(id,date,description,priority,start_date,end_date,recruiter)values(?,?,?,?,?,?,?)";
		try {
			pstmt=connection.prepareStatement(query);
			pstmt.setInt(1,id);
			pstmt.setString(2, date);
			pstmt.setString(3, description);
			pstmt.setString(4, priority);
			pstmt.setString(5, start_date);
			pstmt.setString(6, end_date);
			pstmt.setString(7,recruiter);
			
			
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count = 0;
		try {
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public List<Register> registerList() {
		// TODO Auto-generated method stub
		return null;
	}

}

