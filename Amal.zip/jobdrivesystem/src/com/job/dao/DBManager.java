package com.job.dao;

import java.sql.Date;
import java.util.List;

import com.job.model.Register;



public interface  DBManager    {
	public int registration(int id, String date, String description, String priority, String start_date,String end_date,String recruiter);

	public List<Register> registerList();


}
