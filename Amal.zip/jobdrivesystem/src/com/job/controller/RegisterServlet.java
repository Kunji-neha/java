package com.job.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.job.dao.DBManager;
import com.job.dao.impl.DBManagerImpl;



@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	private int id;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id =Integer.parseInt( request.getParameter("id"));
		//String date = request.getParameter("date");
		String date = request.getParameter("date");

		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		String start_date = request.getParameter("start_date");
		String end_date = request.getParameter("end_date");
		String recruiter = request.getParameter("recruiter");
		
		DBManager db = new DBManagerImpl();
		int count ;
		
		count=	db.registration(id, date, description, priority, start_date,end_date,recruiter);
		System.out.println(count+"rows/s affected");
		RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
	        rd.forward(request,
	                   response);
	}

}
