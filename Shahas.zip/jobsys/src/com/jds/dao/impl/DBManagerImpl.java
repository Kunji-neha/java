package com.jds.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jds.dao.DBManager;
import com.jds.model.Application;

public class DBManagerImpl implements DBManager{

	private static final String URL="jdbc:mysql://localhost:3306/test";
	private static final String USER="root";
	private static final String PASS="root123";
	
	Connection con;
	PreparedStatement pstmt;
	ResultSet rst;
	
	private void getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(URL, USER, PASS);
	}
	
	public void addApplication(Application app) {
		try {
			getConnection();
			String sql="INSERT INTO APPLICANTS VALUES(?,?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, app.getId());
			pstmt.setString(2, app.getDate());
			pstmt.setString(3, app.getDescription());
			pstmt.setString(4, app.getPriority());
			pstmt.setString(5, app.getStart_date());
			pstmt.setString(6, app.getEnd_date());
			pstmt.setString(7, app.getRecruiter());
			pstmt.execute();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Application> viewApplication(){
		List<Application> result=new ArrayList<Application>();
		try {
			getConnection();
			String sql="SELECT * FROM APPLICANTS";
			pstmt=con.prepareStatement(sql);
			rst=pstmt.executeQuery();
			while(rst.next()) {
				Application app=new Application(rst.getString("id"), rst.getString("date"), rst.getString("description"), rst.getString("priority"),
						rst.getString("start_date"), rst.getString("end_date"), rst.getString("recruiter"));
				result.add(app);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}
	
}	
