package com.jds.dao;

import java.util.List;

import com.jds.model.Application;

public interface DBManager {
	
	public void addApplication(Application app);
	
	public List<Application> viewApplication();

}
