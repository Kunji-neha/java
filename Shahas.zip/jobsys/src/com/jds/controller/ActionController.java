package com.jds.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jds.dao.DBManager;
import com.jds.dao.impl.DBManagerImpl;
import com.jds.model.Application;

/**
 * Servlet implementation class ActionController
 */
@WebServlet("/action")
public class ActionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("ac");
		if("add".equals(action)) {
			RequestDispatcher rd=request.getRequestDispatcher("/add.jsp");
			rd.forward(request, response);
		}else if("view".equals(action)) {
			
			DBManager dao=new DBManagerImpl();
			List<Application>list=dao.viewApplication();
			
			request.setAttribute("list",list);
			RequestDispatcher rd=request.getRequestDispatcher("/view.jsp");
			rd.forward(request, response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		String date=request.getParameter("date");
		String description=request.getParameter("desc");
		String priority=request.getParameter("priority");
		String start=request.getParameter("sdate");
		String end=request.getParameter("edate");
		String recruiter=request.getParameter("rec");
		
		Application app=new Application(id, date, description, priority, start, end, recruiter);
		DBManager dao=new DBManagerImpl();
		dao.addApplication(app);
		RequestDispatcher rd=request.getRequestDispatcher("/banner.jsp");
		rd.forward(request, response);
	}

}
