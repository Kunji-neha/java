package com.jobdrivesystem;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrivesystem.db.JobDriverSystemManager;
import com.jobdrivesystem.db.impl.JobDriverSystemManagerImpl;
import com.jobdrivesystem.model.Applicant;


@WebServlet("/NewApplicantServlet")
public class NewApplicantServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Applicant applicant=new Applicant();
		Date reg_date= Date.valueOf(req.getParameter("regi_date"));
		
		String description=req.getParameter("description");
		String priority=req.getParameter("priority");
		Date startdate= Date.valueOf(req.getParameter("startdate"));
		Date enddate= Date.valueOf(req.getParameter("enddate"));
		String recruiter=req.getParameter("recruiter");
	
		JobDriverSystemManager jdsm=new JobDriverSystemManagerImpl();
		applicant.setRegidate(reg_date);
		
		applicant.setDescription(description);
		applicant.setPriority(priority);
		applicant.setStartdate(startdate);
		applicant.setEnddate(enddate);
		applicant.setRecruiter(recruiter);
		
		
		
		
		jdsm.createApplicant(applicant);
		RequestDispatcher rd=req.getRequestDispatcher("/index.html");
		rd.forward(req, resp);
		
		
	}

}
