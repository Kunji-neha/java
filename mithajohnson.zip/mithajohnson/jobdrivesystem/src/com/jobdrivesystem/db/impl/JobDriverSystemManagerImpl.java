package com.jobdrivesystem.db.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jobdrivesystem.db.JobDriverSystemManager;
import com.jobdrivesystem.model.Applicant;

public class JobDriverSystemManagerImpl implements JobDriverSystemManager {

	@Override
	public Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jobdrivesystem", "root", "Ust@1234678");

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return con;
	}

	@Override
	public void createApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		try {
			PreparedStatement ps = con.prepareStatement(
					"insert into tracker (regi_date, description, priority, stratdate,enddate,recruiter) values (?,?,?,?,?,?)");
			ps.setDate(1, applicant.getRegidate());
			ps.setString(2, applicant.getDescription());
			ps.setString(3, applicant.getPriority());
			ps.setDate(4, applicant.getStartdate());
			ps.setDate(5, applicant.getEnddate());
			ps.setString(6, applicant.getRecruiter());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public List<Applicant> view() {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		List<Applicant> applicant = new ArrayList<>();

		PreparedStatement selectStmnt;
		try {
			selectStmnt = con.prepareStatement("select * from tracker");
			ResultSet rs = selectStmnt.executeQuery();
			while (rs.next()) {

				applicant.add(new Applicant(rs.getInt(1), rs.getDate(2), rs.getString(3), rs.getString(4),
						rs.getDate(5), rs.getDate(6), rs.getString(7)));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return applicant;

	}

}
