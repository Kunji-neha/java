package com.jobdrivesystem.db;

import java.sql.Connection;
import java.util.List;

import com.jobdrivesystem.model.Applicant;

public interface JobDriverSystemManager {
	public Connection getConnection();

	void createApplicant(Applicant applicant);

	public List<Applicant> view();

}
