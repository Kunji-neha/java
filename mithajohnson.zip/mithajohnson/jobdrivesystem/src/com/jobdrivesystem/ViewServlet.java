package com.jobdrivesystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrivesystem.db.JobDriverSystemManager;
import com.jobdrivesystem.db.impl.JobDriverSystemManagerImpl;
import com.jobdrivesystem.model.Applicant;


@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	@Override
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		JobDriverSystemManager jdsm=new JobDriverSystemManagerImpl();
		List<Applicant> list = new ArrayList<>();
		list=jdsm.view();
		req.setAttribute("applicant", list);
		RequestDispatcher rd=req.getRequestDispatcher("/view.jsp");
		rd.forward(req, resp);
	}


	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
		
	}

}
