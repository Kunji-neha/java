package com.jobdrivesystem.model;

import java.sql.Date;

public class Applicant {
	private int id;
	private Date regidate;
	private String description;
	private String priority;
	private Date startdate;
	private Date enddate;
	private String recruiter;

	public Applicant() {
		// TODO Auto-generated constructor stub
	}

	public Applicant(int id, Date regidate, String description, String priority, Date startdate, Date enddate,
			String recruiter) {
		this.id = id;
		this.regidate = regidate;
		this.description = description;
		this.priority = priority;
		this.startdate = startdate;
		this.enddate = enddate;
		this.recruiter = recruiter;

	}

	public Date getRegidate() {
		return regidate;
	}

	public void setRegidate(Date regidate) {
		this.regidate = regidate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public String getRecruiter() {
		return recruiter;
	}

	public void setRecruiter(String recruiter) {
		this.recruiter = recruiter;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
