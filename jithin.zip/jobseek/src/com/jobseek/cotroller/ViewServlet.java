package com.jobseek.cotroller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobseek.dao.DBManager;
import com.jobseek.dao.impl.DBManagerImpll;
import com.jobseek.model.Applicant;

/**
 * Servlet implementation class ViewServlet
 */
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	List<Applicant> list=new ArrayList<>();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	DBManager db=new DBManagerImpll();
	list=db.viewApplicant();
	
	request.setAttribute("viewdetails", list);
	RequestDispatcher rd=request.getRequestDispatcher("/viewer.jsp");
	rd.forward(request, response);
		
	
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
