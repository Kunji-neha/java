package com.jobseek.cotroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobseek.dao.DBManager;
import com.jobseek.dao.impl.DBManagerImpll;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try
		{
		int id = Integer.parseInt(request.getParameter("id"));
		String date = request.getParameter("date");
		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		String startdate = request.getParameter("startdate");
		String enddate = request.getParameter("enddate");
		String recruiter = request.getParameter("recruiter");
	
		DBManager db=new DBManagerImpll();
		int count;
		count=db.insertApplicant(id, date, description,priority, startdate, enddate, recruiter);
		request.setAttribute("add", count);
		RequestDispatcher rd = request.getRequestDispatcher("/ViewServlet");
		rd.forward(request, response);
		}
		catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
