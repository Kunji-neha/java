package com.jobseek.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jobseek.dao.DBManager;
import com.jobseek.model.Applicant;


public class DBManagerImpll implements DBManager {

	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	String sql = "jdbc:mysql://localhost:3306/jobseeker";
	String user = "root";
	String pass = "root123";

	@Override
	public int insertApplicant(int id, String date, String description, String priority,String startdate, String enddate,
			String recruiter) {
		int count = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			
			String query = "INSERT INTO APPLICANT(ID, DATE, DESCRIPTION,PRIORITY, STARTDATE, ENDDATE,RECRUITER) VALUES(?, ?, ?, ?, ?,?,?)";
			ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ps.setString(2, date);
			ps.setString(3, description);
		
			ps.setString(4, priority);
			ps.setString(5, startdate);
			ps.setString(6, enddate);
			ps.setString(7, recruiter);
			
			
			count = ps.executeUpdate();
			
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
		

	}

	@Override
	public List<Applicant> viewApplicant() {
		
		List<Applicant> list=new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			String query = "SELECT * FROM APPLICANT";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				list.add(new Applicant(rs.getInt("id"),

						rs.getString("date"), rs.getString("description"),rs.getString("priority"),
						rs.getString("startdate"),
						rs.getString("enddate"),rs.getString("recruiter")));
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
		
	}

}
