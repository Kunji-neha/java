package com.jobseek.dao;

import java.util.List;

import com.jobseek.model.Applicant;

public interface DBManager {
	
	public int insertApplicant(int id, String date, String description, String priority,String startdate, String enddate, String recruiter);
	public List<Applicant> viewApplicant();
	

}
