package com.JobDriveSystem.model;

import java.sql.Date;

public class Application {
	int id;
	String date;
	String description;
	String priority;
	String startdate;
	String enddate;
	String recruiter;

	public Application(int id, String date, String description, String priority, String startdate, String enddate,
			String recruiter) {
		super();
		this.id = id;
		this.date = date;
		this.description = description;
		this.priority = priority;
		this.startdate = startdate;
		this.enddate = enddate;
		this.recruiter = recruiter;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getRecruiter() {
		return recruiter;
	}

	public void setRecruiter(String recruiter) {
		this.recruiter = recruiter;
	}

}
