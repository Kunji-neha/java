package com.JobDriveSystem.database;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.JobDriveSystem.model.Application;

public interface DBManager {
	public List<Application> applicationList();

	public int addToApplication(int id, String date, String description, String priority, String startdate,
			String enddate, String recruiter);
}
