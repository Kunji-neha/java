package com.JobDriveSystem.database.Impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.JobDriveSystem.database.DBManager;
import com.JobDriveSystem.model.Application;

public class DBManagerImpl implements DBManager {
	private Connection con;
	private PreparedStatement ps;
	private PreparedStatement ps1;
	private ResultSet rs;
	String sql = "jdbc:mysql://localhost:3306/jobdrivesystem";
	String user = "root";
	String pass = "goku";
	String name = null;

	@Override
	public int addToApplication(int id, String date, String description, String priority, String startdate,
			String enddate, String recruiter) {
		int count = 0;
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			ps = con.prepareStatement(
					"INSERT INTO APPLICATION(ID,DATE,DESCRIPTION,PRIORITY,STARTDATE,ENDDATE,RECRUITER) VALUES(?,?,?,?,?,?,?)");
			ps.setInt(1, id);
			ps.setString(2, date);
			ps.setString(3, description);
			ps.setString(4, priority);
			ps.setString(5, startdate);
			ps.setString(6, enddate);
			ps.setString(7, recruiter);
			count = ps.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

	@Override
	public List<Application> applicationList() {
		List<Application> application = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			String query = "SELECT * FROM APPLICATION";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				application.add(new Application(rs.getInt("id"),

						rs.getString("date"), rs.getString("description"), rs.getString("priority"),
						rs.getString("startdate"), rs.getString("enddate"), rs.getString("recruiter")));
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return application;
	}

}
