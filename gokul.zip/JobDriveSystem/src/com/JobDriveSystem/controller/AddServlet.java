package com.JobDriveSystem.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.JobDriveSystem.database.DBManager;
import com.JobDriveSystem.database.Impl.DBManagerImpl;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/addServlet")
public class AddServlet extends HttpServlet {
	DBManager db = new DBManagerImpl();
	int count = 0;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd1 = request.getRequestDispatcher("/register.jsp");
		rd1.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String date = request.getParameter("date");
		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		String startdate = request.getParameter("startdate");
		String enddate = request.getParameter("enddate");
		String recruiter = request.getParameter("recruiter");
		count = db.addToApplication(id, date, description, priority, startdate, enddate, recruiter);
		request.setAttribute("register", count);
		RequestDispatcher rd1 = request.getRequestDispatcher("/registerServlet");
		rd1.forward(request, response);
	}

}
