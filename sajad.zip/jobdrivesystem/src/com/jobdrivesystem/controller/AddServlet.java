package com.jobdrivesystem.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrivesystem.dao.DBManager;
import com.jobdrivesystem.dao.impl.DBManagerImpl;
import com.jobdrivesystem.model.Applications;

@WebServlet("/action")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String action=request.getParameter("ac");
		if("add".equals(action)) {
			RequestDispatcher rd=request.getRequestDispatcher("/newapplication.jsp");
			rd.forward(request, response);
		}else if("view".equals(action)) {
			
			DBManager dao=new DBManagerImpl();
			List<Applications> list=dao.viewApplication();
			
			request.setAttribute("list",list);
			RequestDispatcher rd=request.getRequestDispatcher("/view.jsp");
			rd.forward(request, response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("/index.jsp");
			rd.forward(request, response);
		}

		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
		
		String id=request.getParameter("id");
		String date=request.getParameter("date");
		String description=request.getParameter("description");
		String priority=request.getParameter("priority");
		String start_date=request.getParameter("start_date");
		String end_date=request.getParameter("end_date");
		String assign_to=request.getParameter("assign_to");
		DBManager dao=new DBManagerImpl();

		//System.out.println(id+date+description+priority+start_date+end_date+assign_to);
		dao.setApplication( id,  date,  description,  priority, start_date,  end_date,  assign_to);
		
		
		RequestDispatcher rd=request.getRequestDispatcher("/added.jsp");
		rd.forward(request, response);
		
	}

}
