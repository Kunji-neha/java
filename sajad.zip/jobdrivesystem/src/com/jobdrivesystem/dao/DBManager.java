package com.jobdrivesystem.dao;

import java.util.List;

import com.jobdrivesystem.model.Applications;

public interface DBManager {

	
	public void setApplication(String id, String date, String description, String priority, String start_date, String end_date, String assign_to); 
	public List<Applications> viewApplication();
}
