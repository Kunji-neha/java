package com.jobdrivesystem.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jobdrivesystem.dao.DBManager;
import com.jobdrivesystem.model.Applications;

public class DBManagerImpl implements DBManager {
	
	public static final String url = "jdbc:mysql://localhost:3306/jobdrive";
	public static final String user = "root";
	public static final String pass = "root1234";
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rst = null;
	String sql = null;

	public void getConnection() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(url, user, pass);

	}

	@Override
	public void setApplication(String id, String date, String description, String priority,
			String start_date, String end_date, String assign_to) 
	{
		try {
			getConnection();
			sql = "INSERT INTO APPLICATIONS (ID,DATE,DESCRIPTION,PRIORITY,START_DATE,END_DATE,ASSIGN_TO) VALUES(?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, date);
			pstmt.setString(3, description);
			pstmt.setString(4, priority);
			pstmt.setString(5, start_date);
			pstmt.setString(6, end_date);
			pstmt.setString(7, assign_to);
			pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	public List<Applications> viewApplication(){
		List<Applications> result=new ArrayList<Applications>();
		try {
			getConnection();
			String sql="SELECT * FROM APPLICATIONS";
			pstmt=con.prepareStatement(sql);
			rst=pstmt.executeQuery();
			while(rst.next()) {
				Applications app=new Applications(rst.getString("id"), rst.getString("date"), rst.getString("description"), rst.getString("priority"),
						rst.getString("start_date"), rst.getString("end_date"), rst.getString("assign_to"));
				result.add(app);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}

	
	
}
	

