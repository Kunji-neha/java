package com.jobdrivesystem.model;

public class NewApplication {
	private int appId;
	private String regDate;
	private String description;
	private String priority;
	private String startDate;
	private String endDate;
	private String assignedTo;

	public NewApplication(int appId, String regDate, String description, String priority, String startDate, String endDate,
			String assignedTo) {
		super();
		this.appId = appId;
		this.regDate = regDate;
		this.description = description;
		this.priority = priority;
		this.startDate = startDate;
		this.endDate = endDate;
		this.assignedTo = assignedTo;
	}

	/**
	 * @return the appId
	 */
	public int getAppId() {
		return appId;
	}

	/**
	 * @param appId the appId to set
	 */
	public void setAppId(int appId) {
		this.appId = appId;
	}

	/**
	 * @return the regDate
	 */
	public String getRegDate() {
		return regDate;
	}

	/**
	 * @param regDate the regDate to set
	 */
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	/**
	 * @return the description
	 */
	public  String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the assignedTo
	 */
	public String getAssignedTo() {
		return assignedTo;
	}

	/**
	 * @param assignedTo the assignedTo to set
	 */
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	@Override
	public String toString() {
		return "NewApp [appId=" + appId + ", regDate=" + regDate + ", description=" + description + ", priority="
				+ priority + ", startDate=" + startDate + ", endDate=" + endDate + ", assignedTo=" + assignedTo + "]";
	}

}
