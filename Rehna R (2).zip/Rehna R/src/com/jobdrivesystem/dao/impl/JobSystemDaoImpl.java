package com.jobdrivesystem.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jobdrivesystem.dao.JobSystemDao;
import com.jobdrivesystem.model.NewApplication;

public class JobSystemDaoImpl implements JobSystemDao {
	private Connection con;
	private PreparedStatement ps;
	private PreparedStatement ps1;
	private ResultSet rs;
	String sql = "jdbc:mysql://localhost:3306/jobdrive";
	String user = "root";
	String pass = "Friendship";
	String name = null;

	@Override
	public List<NewApplication> applicantList() {
		List<NewApplication> applicants = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			String query = "SELECT * FROM  NEW";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				applicants.add(new NewApplication(rs.getInt("appId"),

						rs.getString("regDate"), rs.getString("description"), rs.getString("priority"),
						rs.getString("startDate"), rs.getString("endDate"), rs.getString("assignedTo")));
			}

		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

		return applicants;

	}

	@Override
	public int newApplication(int appId, String regDate, String description, String priority, String startDate,
			String endDate, String assignedTo) {

		int add = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(sql, user, pass);
			String query = "INSERT INTO NEW (appId,regDate,description,priority ,startDate,endDate,,assignedTo) VALUES(?, ?, ?, ?,?,?,?)";
			ps1 = con.prepareStatement(query);

			ps1.setInt(1, appId);
			ps1.setString(2, regDate);
			ps1.setString(3, description);
			ps1.setString(4, priority);
			ps1.setString(5, startDate);
			ps1.setString(6, endDate);
			ps1.setString(7, assignedTo);

			add = ps1.executeUpdate();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return add;

	}
}
