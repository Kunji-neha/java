package com.jobdrivesystem.dao;

import java.util.List;

import com.jobdrivesystem.model.NewApplication;

public interface JobSystemDao {

	public List<NewApplication> applicantList();

	public int newApplication(int appId, String regDate, String description, String priority, String startDate,
			String endDate, String assignedTo);

}
