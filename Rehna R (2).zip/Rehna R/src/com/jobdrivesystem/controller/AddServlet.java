package com.jobdrivesystem.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jobdrivesystem.dao.JobSystemDao;
import com.jobdrivesystem.dao.impl.JobSystemDaoImpl;
import com.jobdrivesystem.model.NewApplication;

@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		JobSystemDao db = new JobSystemDaoImpl();
		int appId = Integer.parseInt(request.getParameter("appId"));
		String regDate = request.getParameter("regDate");
		String description = request.getParameter("description");
		String priority = request.getParameter("priority");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		String assignedTo = request.getParameter("assignedTo");
		int add = db.newApplication(appId, regDate, description, priority, startDate, endDate, assignedTo);

		RequestDispatcher rd = request.getRequestDispatcher("/addout.jsp ");
		rd.forward(request, response);
		doGet(request, response);
	}

}
